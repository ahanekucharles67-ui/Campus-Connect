import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Upload, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/sell")({
  head: () => ({ meta: [{ title: "Sell — Campus" }] }),
  component: Sell,
});

const CATEGORIES = ["Phones", "Laptops", "Fashion", "Books", "Gadgets", "Furniture", "Other"];

function Sell() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [title, setTitle] = useState("");
  const [price, setPrice] = useState("");
  const [category, setCategory] = useState(CATEGORIES[0]);
  const [school, setSchool] = useState("");
  const [description, setDescription] = useState("");
  const [files, setFiles] = useState<File[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    try {
      const urls: string[] = [];
      for (const f of files) {
        const path = `${user.id}/${Date.now()}-${f.name.replace(/\s/g, "_")}`;
        const { error } = await supabase.storage.from("products").upload(path, f, { upsert: false });
        if (error) throw error;
        const { data } = supabase.storage.from("products").getPublicUrl(path);
        urls.push(data.publicUrl);
      }
      const { data: row, error } = await supabase
        .from("products")
        .insert({
          seller_id: user.id,
          title: title.trim(),
          description: description.trim() || null,
          price: Number(price),
          category,
          school: school.trim() || null,
          images: urls,
        })
        .select("id")
        .single();
      if (error) throw error;
      toast.success("Listing posted!");
      navigate({ to: "/product/$id", params: { id: row.id } });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Failed to post");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AppShell>
      <header className="sticky top-0 z-30 flex items-center justify-between border-b border-border/40 bg-background/70 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-3 backdrop-blur-xl">
        <Link to="/" className="text-sm text-muted-foreground">Cancel</Link>
        <h1 className="font-display text-base font-bold">New listing</h1>
        <span className="w-12" />
      </header>

      <form onSubmit={submit} className="space-y-4 px-4 pt-4">
        <div>
          <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">Photos</label>
          <div className="grid grid-cols-3 gap-2">
            {files.map((f, i) => (
              <div key={i} className="relative aspect-square overflow-hidden rounded-xl bg-surface">
                <img src={URL.createObjectURL(f)} alt="" className="h-full w-full object-cover" />
                <button
                  type="button"
                  onClick={() => setFiles(files.filter((_, j) => j !== i))}
                  className="absolute right-1 top-1 rounded-full bg-background/80 p-1"
                >
                  <X className="h-3 w-3" />
                </button>
              </div>
            ))}
            {files.length < 6 && (
              <label className="flex aspect-square cursor-pointer items-center justify-center rounded-xl border border-dashed border-border bg-surface/50">
                <Upload className="h-5 w-5 text-muted-foreground" />
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={(e) => {
                    const list = Array.from(e.target.files ?? []);
                    setFiles([...files, ...list].slice(0, 6));
                  }}
                />
              </label>
            )}
          </div>
        </div>

        <Field label="Title">
          <input required value={title} onChange={(e) => setTitle(e.target.value)} maxLength={100}
            className="w-full rounded-2xl bg-input px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </Field>

        <Field label="Price (₦)">
          <input required type="number" min="0" value={price} onChange={(e) => setPrice(e.target.value)}
            className="w-full rounded-2xl bg-input px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </Field>

        <Field label="Category">
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((c) => (
              <button key={c} type="button" onClick={() => setCategory(c)}
                className={`rounded-full px-4 py-1.5 text-xs font-medium ${
                  category === c ? "bg-gradient-primary text-primary-foreground shadow-glow" : "bg-surface text-muted-foreground"
                }`}>{c}</button>
            ))}
          </div>
        </Field>

        <Field label="School / Campus">
          <input value={school} onChange={(e) => setSchool(e.target.value)} placeholder="e.g. UniPort"
            className="w-full rounded-2xl bg-input px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </Field>

        <Field label="Description">
          <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} maxLength={1000}
            className="w-full resize-none rounded-2xl bg-input px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-ring" />
        </Field>

        <button disabled={submitting}
          className="w-full rounded-2xl bg-gradient-primary py-3.5 text-sm font-semibold text-primary-foreground shadow-glow disabled:opacity-60">
          {submitting ? "Posting..." : "Post listing"}
        </button>
      </form>
    </AppShell>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <label className="mb-2 block text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</label>
      {children}
    </div>
  );
}
