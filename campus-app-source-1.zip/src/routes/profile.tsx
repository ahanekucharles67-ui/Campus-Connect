import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { BadgeCheck, LogOut, Star, Pencil } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile — Campus" }] }),
  component: ProfilePage,
});

function ProfilePage() {
  const { user, loading: authLoading, signOut } = useAuth();
  const navigate = useNavigate();
  const [editing, setEditing] = useState(false);
  const [fullName, setFullName] = useState("");
  const [school, setSchool] = useState("");
  const [department, setDepartment] = useState("");

  useEffect(() => { if (!authLoading && !user) navigate({ to: "/login" }); }, [user, authLoading, navigate]);

  const { data: profile, refetch } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase.from("profiles").select("*").eq("id", user!.id).single();
      if (error) throw error;
      return data;
    },
  });

  const { data: listings } = useQuery({
    queryKey: ["my-listings", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<ProductCardData[]> => {
      const { data, error } = await supabase.from("products")
        .select("id,title,price,images,school,category").eq("seller_id", user!.id).order("created_at", { ascending: false });
      if (error) throw error;
      return data ?? [];
    },
  });

  useEffect(() => {
    if (profile) {
      setFullName(profile.full_name ?? "");
      setSchool(profile.school ?? "");
      setDepartment(profile.department ?? "");
    }
  }, [profile]);

  const save = async () => {
    const { error } = await supabase.from("profiles").update({
      full_name: fullName.trim() || null, school: school.trim() || null, department: department.trim() || null,
    }).eq("id", user!.id);
    if (error) toast.error(error.message); else { toast.success("Profile updated"); setEditing(false); refetch(); }
  };

  if (!user) return null;

  return (
    <AppShell>
      <header className="border-b border-border/40 bg-background/70 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-4 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <h1 className="font-display text-2xl font-bold">Profile</h1>
          <button onClick={signOut} className="grid h-9 w-9 place-items-center rounded-full bg-surface" aria-label="Sign out">
            <LogOut className="h-4 w-4" />
          </button>
        </div>
      </header>

      <section className="px-4 pt-6">
        <div className="flex items-center gap-4">
          <div className="h-20 w-20 overflow-hidden rounded-full bg-gradient-primary shadow-glow">
            {profile?.avatar_url
              ? <img src={profile.avatar_url} alt="" className="h-full w-full object-cover" />
              : <div className="grid h-full w-full place-items-center text-2xl font-bold text-primary-foreground">{(profile?.full_name ?? user.email ?? "?").charAt(0).toUpperCase()}</div>}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5">
              <h2 className="truncate text-lg font-bold">{profile?.full_name ?? "Student"}</h2>
              {profile?.verified && <BadgeCheck className="h-5 w-5 text-primary-glow" />}
            </div>
            <p className="truncate text-xs text-muted-foreground">{profile?.school ?? "Add your school"}</p>
            <div className="mt-1 flex items-center gap-1 text-xs">
              <Star className="h-3 w-3 fill-accent text-accent" />
              <span className="font-semibold">{profile?.trust_score ?? 100}</span>
              <span className="text-muted-foreground">trust score</span>
            </div>
          </div>
          <button onClick={() => setEditing((v) => !v)} className="grid h-9 w-9 place-items-center rounded-full bg-surface">
            <Pencil className="h-4 w-4" />
          </button>
        </div>

        {editing && (
          <div className="mt-4 space-y-2 rounded-2xl bg-card p-4 shadow-card">
            <input value={fullName} onChange={(e) => setFullName(e.target.value)} placeholder="Full name"
              className="w-full rounded-xl bg-input px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <input value={school} onChange={(e) => setSchool(e.target.value)} placeholder="School"
              className="w-full rounded-xl bg-input px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <input value={department} onChange={(e) => setDepartment(e.target.value)} placeholder="Department"
              className="w-full rounded-xl bg-input px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-ring" />
            <button onClick={save} className="w-full rounded-xl bg-gradient-primary py-2 text-sm font-semibold text-primary-foreground shadow-glow">
              Save
            </button>
          </div>
        )}
      </section>

      <section className="px-4 pt-8">
        <div className="mb-3 flex items-end justify-between">
          <h3 className="font-display text-lg font-bold">My listings</h3>
          <Link to="/sell" className="text-xs text-primary-glow">+ New</Link>
        </div>
        {!listings?.length ? (
          <p className="rounded-2xl border border-dashed border-border bg-surface/50 p-6 text-center text-sm text-muted-foreground">
            You haven't posted anything yet.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {listings.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        )}
      </section>
    </AppShell>
  );
}
