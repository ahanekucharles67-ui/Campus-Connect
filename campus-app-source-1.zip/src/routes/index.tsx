import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Bell, Sparkles, ShieldCheck } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Campus — Student Marketplace" },
      { name: "description", content: "Discover what students near you are selling right now." },
    ],
  }),
  component: Home,
});

const CATEGORIES = ["All", "Phones", "Laptops", "Fashion", "Books", "Gadgets", "Furniture"];

function Home() {
  const { user } = useAuth();
  const { data: products, isLoading } = useQuery({
    queryKey: ["products", "feed"],
    queryFn: async (): Promise<ProductCardData[]> => {
      const { data, error } = await supabase
        .from("products")
        .select("id,title,price,images,school,category")
        .eq("status", "available")
        .order("created_at", { ascending: false })
        .limit(50);
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <AppShell>
      <header className="sticky top-0 z-30 border-b border-border/40 bg-background/70 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-3 backdrop-blur-xl">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">
              <span className="text-gradient">Campus</span>
            </h1>
            <p className="text-xs text-muted-foreground">Your school. Your market.</p>
          </div>
          <div className="flex items-center gap-2">
            <Link
              to="/admin"
              className="inline-flex items-center gap-1 rounded-full border border-primary-glow/40 bg-primary-glow/10 px-3 py-2 text-xs font-semibold text-primary-glow"
              aria-label="Admin dashboard"
            >
              <ShieldCheck className="h-4 w-4" />
              Admin
            </Link>
            <button className="grid h-10 w-10 place-items-center rounded-full bg-surface" aria-label="Notifications">
              <Bell className="h-5 w-5" />
            </button>
            {!user && (
              <Link to="/login" className="rounded-full bg-gradient-primary px-4 py-2 text-xs font-semibold text-primary-foreground shadow-glow">
                Sign in
              </Link>
            )}
          </div>
        </div>
      </header>

      <section className="px-4 pt-4">
        <div className="rounded-2xl bg-gradient-primary p-5 shadow-glow">
          <div className="flex items-center gap-2 text-primary-foreground">
            <Sparkles className="h-5 w-5" />
            <p className="text-sm font-semibold uppercase tracking-wide">Trending on campus</p>
          </div>
          <p className="mt-2 font-display text-xl font-bold leading-tight text-primary-foreground">
            Find verified deals from students near you.
          </p>
        </div>
      </section>

      <div className="no-scrollbar mt-5 flex gap-2 overflow-x-auto px-4">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            className="shrink-0 rounded-full border border-border bg-surface px-4 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground"
          >
            {c}
          </button>
        ))}
      </div>

      <section className="px-4 pt-5">
        <div className="mb-3 flex items-end justify-between">
          <h2 className="font-display text-lg font-bold">Fresh drops</h2>
          <Link to="/search" className="text-xs text-primary-glow">See all</Link>
        </div>
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-surface" />
            ))}
          </div>
        ) : !products?.length ? (
          <EmptyFeed />
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {products.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        )}
      </section>
    </AppShell>
  );
}

function EmptyFeed() {
  return (
    <div className="rounded-2xl border border-dashed border-border bg-surface/50 p-8 text-center">
      <p className="text-sm font-semibold">No listings yet</p>
      <p className="mt-1 text-xs text-muted-foreground">Be the first to drop something on your campus.</p>
      <Link to="/sell" className="mt-4 inline-flex rounded-full bg-gradient-primary px-5 py-2 text-xs font-semibold text-primary-foreground shadow-glow">
        Post a listing
      </Link>
    </div>
  );
}
