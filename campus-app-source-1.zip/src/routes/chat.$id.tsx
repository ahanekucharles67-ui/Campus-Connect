import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { ArrowLeft, Send } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/chat/$id")({
  head: () => ({ meta: [{ title: "Chat — Campus" }] }),
  component: Thread,
});

type Message = { id: string; conversation_id: string; sender_id: string; content: string; created_at: string };

function Thread() {
  const { id } = Route.useParams();
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  const { data: convo } = useQuery({
    queryKey: ["conversation", id],
    enabled: !!user,
    queryFn: async () => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id,buyer_id,seller_id, product:products(id,title,images,price)")
        .eq("id", id)
        .single();
      if (error) throw error;
      const product = Array.isArray(data.product) ? data.product[0] ?? null : data.product;
      const otherId = data.buyer_id === user!.id ? data.seller_id : data.buyer_id;
      const { data: other } = await supabase.from("profiles").select("id,full_name,avatar_url").eq("id", otherId).single();
      return { ...data, product, other };
    },
  });

  const { data: messages } = useQuery({
    queryKey: ["messages", id],
    enabled: !!user,
    queryFn: async (): Promise<Message[]> => {
      const { data, error } = await supabase.from("messages").select("*").eq("conversation_id", id).order("created_at");
      if (error) throw error;
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`messages:${id}`)
      .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages", filter: `conversation_id=eq.${id}` },
        () => qc.invalidateQueries({ queryKey: ["messages", id] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [id, qc, user]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: "smooth" }); }, [messages]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim() || !user) return;
    const content = text.trim();
    setText("");
    const { error } = await supabase.from("messages").insert({ conversation_id: id, sender_id: user.id, content });
    if (error) return;
    await supabase.from("conversations").update({ last_message: content, last_message_at: new Date().toISOString() }).eq("id", id);
    qc.invalidateQueries({ queryKey: ["messages", id] });
  };

  return (
    <div className="mx-auto flex h-[100dvh] w-full max-w-md flex-col bg-gradient-page">
      <header className="flex items-center gap-3 border-b border-border/40 bg-background/80 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-3 backdrop-blur-xl">
        <Link to="/chat" className="grid h-9 w-9 place-items-center rounded-full bg-surface">
          <ArrowLeft className="h-4 w-4" />
        </Link>
        <div className="h-10 w-10 overflow-hidden rounded-full bg-gradient-primary">
          {convo?.other?.avatar_url
            ? <img src={convo.other.avatar_url} alt="" className="h-full w-full object-cover" />
            : <div className="grid h-full w-full place-items-center text-sm font-bold text-primary-foreground">{(convo?.other?.full_name ?? "?").charAt(0).toUpperCase()}</div>}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold">{convo?.other?.full_name ?? "Student"}</p>
          {convo?.product && <p className="truncate text-xs text-muted-foreground">Re: {convo.product.title}</p>}
        </div>
      </header>

      <div className="flex-1 space-y-2 overflow-y-auto px-4 py-4">
        {messages?.map((m) => {
          const mine = m.sender_id === user?.id;
          return (
            <div key={m.id} className={`flex ${mine ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-4 py-2 text-sm ${
                mine ? "bg-gradient-primary text-primary-foreground" : "bg-surface text-foreground"
              }`}>{m.content}</div>
            </div>
          );
        })}
        <div ref={endRef} />
      </div>

      <form onSubmit={send} className="flex items-center gap-2 border-t border-border/40 bg-background/80 px-3 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-xl">
        <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Message..."
          className="flex-1 rounded-full bg-input px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring" />
        <button type="submit" className="grid h-10 w-10 place-items-center rounded-full bg-gradient-primary text-primary-foreground shadow-glow">
          <Send className="h-4 w-4" />
        </button>
      </form>
    </div>
  );
}
