import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";
import { AppShell } from "@/components/AppShell";
import { ShieldCheck, Users, Package, MessageSquare, Star, Trash2, Loader2 } from "lucide-react";

export const Route = createFileRoute("/admin")({
  component: AdminDashboard,
});

type Stats = { users: number; products: number; conversations: number; reviews: number };
type ProductRow = { id: string; title: string; price: number; status: string; created_at: string; seller_id: string };
type UserRow = { id: string; full_name: string | null; school: string | null; trust_score: number; verified: boolean };

function AdminDashboard() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const [checking, setChecking] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [stats, setStats] = useState<Stats>({ users: 0, products: 0, conversations: 0, reviews: 0 });
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [tab, setTab] = useState<"overview" | "products" | "users">("overview");

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      navigate({ to: "/login" });
      return;
    }
    (async () => {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();
      setIsAdmin(!!data);
      setChecking(false);
    })();
  }, [user, authLoading, navigate]);

  useEffect(() => {
    if (!isAdmin) return;
    (async () => {
      const [u, p, c, r, plist, ulist] = await Promise.all([
        supabase.from("profiles").select("*", { count: "exact", head: true }),
        supabase.from("products").select("*", { count: "exact", head: true }),
        supabase.from("conversations").select("*", { count: "exact", head: true }),
        supabase.from("reviews").select("*", { count: "exact", head: true }),
        supabase.from("products").select("id,title,price,status,created_at,seller_id").order("created_at", { ascending: false }).limit(50),
        supabase.from("profiles").select("id,full_name,school,trust_score,verified").order("created_at", { ascending: false }).limit(50),
      ]);
      setStats({
        users: u.count ?? 0,
        products: p.count ?? 0,
        conversations: c.count ?? 0,
        reviews: r.count ?? 0,
      });
      setProducts(plist.data ?? []);
      setUsers(ulist.data ?? []);
    })();
  }, [isAdmin]);

  async function deleteProduct(id: string) {
    if (!confirm("Delete this listing?")) return;
    await supabase.from("products").delete().eq("id", id);
    setProducts((prev) => prev.filter((p) => p.id !== id));
  }

  async function toggleVerified(u: UserRow) {
    await supabase.from("profiles").update({ verified: !u.verified }).eq("id", u.id);
    setUsers((prev) => prev.map((x) => (x.id === u.id ? { ...x, verified: !u.verified } : x)));
  }

  if (authLoading || checking) {
    return (
      <AppShell>
        <div className="flex h-screen items-center justify-center">
          <Loader2 className="h-6 w-6 animate-spin text-primary-glow" />
        </div>
      </AppShell>
    );
  }

  if (!isAdmin) {
    return (
      <AppShell>
        <div className="flex flex-col items-center justify-center px-6 pt-32 text-center">
          <ShieldCheck className="h-12 w-12 text-muted-foreground" />
          <h1 className="mt-4 font-display text-2xl">Admins only</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            You don't have access to this dashboard.
          </p>
          <Link to="/" className="mt-6 rounded-full bg-primary px-5 py-2 text-sm font-medium text-primary-foreground">
            Back home
          </Link>
        </div>
      </AppShell>
    );
  }

  return (
    <AppShell>
      <header className="px-5 pt-6 pb-3">
        <div className="flex items-center gap-2">
          <ShieldCheck className="h-5 w-5 text-primary-glow" />
          <h1 className="font-display text-2xl">Admin</h1>
        </div>
        <p className="text-xs text-muted-foreground">Manage the marketplace</p>
      </header>

      <div className="sticky top-0 z-10 flex gap-1 border-b border-border bg-background/85 px-4 py-2 backdrop-blur-xl">
        {(["overview", "products", "users"] as const).map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 rounded-full py-1.5 text-xs font-medium capitalize transition-colors ${
              tab === t ? "bg-primary text-primary-foreground" : "text-muted-foreground"
            }`}
          >
            {t}
          </button>
        ))}
      </div>

      <div className="px-4 py-4">
        {tab === "overview" && (
          <div className="grid grid-cols-2 gap-3">
            <StatCard icon={Users} label="Users" value={stats.users} />
            <StatCard icon={Package} label="Listings" value={stats.products} />
            <StatCard icon={MessageSquare} label="Chats" value={stats.conversations} />
            <StatCard icon={Star} label="Reviews" value={stats.reviews} />
          </div>
        )}

        {tab === "products" && (
          <ul className="space-y-2">
            {products.map((p) => (
              <li key={p.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card/50 p-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{p.title}</p>
                  <p className="text-xs text-muted-foreground">₦{Number(p.price).toLocaleString()} · {p.status}</p>
                </div>
                <button
                  onClick={() => deleteProduct(p.id)}
                  className="rounded-full p-2 text-destructive hover:bg-destructive/10"
                  aria-label="Delete"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </li>
            ))}
            {products.length === 0 && <p className="text-center text-sm text-muted-foreground">No listings yet</p>}
          </ul>
        )}

        {tab === "users" && (
          <ul className="space-y-2">
            {users.map((u) => (
              <li key={u.id} className="flex items-center justify-between gap-3 rounded-xl border border-border bg-card/50 p-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{u.full_name ?? "Unnamed"}</p>
                  <p className="text-xs text-muted-foreground">{u.school ?? "—"} · trust {u.trust_score}</p>
                </div>
                <button
                  onClick={() => toggleVerified(u)}
                  className={`rounded-full px-3 py-1 text-xs font-medium ${
                    u.verified ? "bg-primary-glow/20 text-primary-glow" : "border border-border text-muted-foreground"
                  }`}
                >
                  {u.verified ? "Verified" : "Verify"}
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </AppShell>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: typeof Users; label: string; value: number }) {
  return (
    <div className="rounded-2xl border border-border bg-card/50 p-4">
      <Icon className="h-5 w-5 text-primary-glow" />
      <p className="mt-2 font-display text-2xl">{value.toLocaleString()}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
