import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Search as SearchIcon } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { ProductCard, type ProductCardData } from "@/components/ProductCard";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/search")({
  head: () => ({ meta: [{ title: "Search — Campus" }] }),
  component: SearchPage,
});

function SearchPage() {
  const [q, setQ] = useState("");
  const { data, isLoading } = useQuery({
    queryKey: ["search", q],
    queryFn: async (): Promise<ProductCardData[]> => {
      let query = supabase
        .from("products")
        .select("id,title,price,images,school,category")
        .eq("status", "available")
        .order("created_at", { ascending: false })
        .limit(60);
      if (q.trim()) query = query.ilike("title", `%${q.trim()}%`);
      const { data, error } = await query;
      if (error) throw error;
      return data ?? [];
    },
  });

  return (
    <AppShell>
      <header className="sticky top-0 z-30 border-b border-border/40 bg-background/70 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-3 backdrop-blur-xl">
        <h1 className="mb-3 font-display text-2xl font-bold">Search</h1>
        <div className="relative">
          <SearchIcon className="absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="iPhone 13, mini fridge, MTH 110..."
            className="w-full rounded-full bg-input py-3 pl-11 pr-4 text-sm outline-none focus:ring-2 focus:ring-ring"
          />
        </div>
      </header>

      <div className="px-4 pt-4">
        {isLoading ? (
          <div className="grid grid-cols-2 gap-3">
            {Array.from({ length: 4 }).map((_, i) => <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-surface" />)}
          </div>
        ) : !data?.length ? (
          <p className="py-12 text-center text-sm text-muted-foreground">No matches yet. Try a different keyword.</p>
        ) : (
          <div className="grid grid-cols-2 gap-3">
            {data.map((p) => <ProductCard key={p.id} p={p} />)}
          </div>
        )}
      </div>
    </AppShell>
  );
}
