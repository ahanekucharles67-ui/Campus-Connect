import { createFileRoute, Link } from "@tanstack/react-router";
import { ShieldCheck, ArrowRight } from "lucide-react";
import { AppShell } from "@/components/AppShell";

export const Route = createFileRoute("/admin-portal")({
  component: AdminPortal,
});

function AdminPortal() {
  return (
    <AppShell hideNav>
      <div className="flex min-h-screen flex-col items-center justify-center px-6 text-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-3xl bg-gradient-primary shadow-glow">
          <ShieldCheck className="h-10 w-10 text-primary-foreground" />
        </div>
        <h1 className="mt-6 font-display text-3xl">Admin Portal</h1>
        <p className="mt-2 max-w-xs text-sm text-muted-foreground">
          Tap the button below to open your marketplace admin dashboard.
        </p>
        <Link
          to="/admin"
          className="mt-8 inline-flex items-center gap-2 rounded-full bg-gradient-primary px-7 py-3 text-sm font-semibold text-primary-foreground shadow-glow transition-transform active:scale-95"
        >
          Go to Admin Dashboard
          <ArrowRight className="h-4 w-4" />
        </Link>
        <Link to="/" className="mt-6 text-xs text-muted-foreground underline">
          Back to app
        </Link>
      </div>
    </AppShell>
  );
}
