import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { formatDistanceToNow } from "date-fns";
import { AppShell } from "@/components/AppShell";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/chat")({
  head: () => ({ meta: [{ title: "Chats — Campus" }] }),
  component: ChatList,
});

type Convo = {
  id: string;
  last_message: string | null;
  last_message_at: string;
  buyer_id: string;
  seller_id: string;
  other: { id: string; full_name: string | null; avatar_url: string | null } | null;
  product: { id: string; title: string; images: string[] } | null;
};

function ChatList() {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (!authLoading && !user) navigate({ to: "/login" });
  }, [user, authLoading, navigate]);

  const { data, isLoading } = useQuery({
    queryKey: ["conversations", user?.id],
    enabled: !!user,
    queryFn: async (): Promise<Convo[]> => {
      const { data, error } = await supabase
        .from("conversations")
        .select("id,last_message,last_message_at,buyer_id,seller_id, product:products(id,title,images)")
        .order("last_message_at", { ascending: false });
      if (error) throw error;
      const rows = data ?? [];
      const otherIds = Array.from(new Set(rows.map((r) => (r.buyer_id === user!.id ? r.seller_id : r.buyer_id))));
      const profileMap: Record<string, { id: string; full_name: string | null; avatar_url: string | null }> = {};
      if (otherIds.length) {
        const { data: profs } = await supabase.from("profiles").select("id,full_name,avatar_url").in("id", otherIds);
        (profs ?? []).forEach((p) => { profileMap[p.id] = p; });
      }
      return rows.map((r) => ({
        ...r,
        product: Array.isArray(r.product) ? r.product[0] ?? null : (r.product as Convo["product"]),
        other: profileMap[r.buyer_id === user!.id ? r.seller_id : r.buyer_id] ?? null,
      }));
    },
  });

  return (
    <AppShell>
      <header className="sticky top-0 z-30 border-b border-border/40 bg-background/70 px-4 pt-[max(1rem,env(safe-area-inset-top))] pb-3 backdrop-blur-xl">
        <h1 className="font-display text-2xl font-bold">Chats</h1>
      </header>

      <div className="px-4 pt-3">
        {isLoading ? (
          <div className="space-y-2">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-16 animate-pulse rounded-2xl bg-surface" />)}</div>
        ) : !data?.length ? (
          <div className="rounded-2xl border border-dashed border-border bg-surface/50 p-8 text-center">
            <p className="text-sm font-semibold">No chats yet</p>
            <p className="mt-1 text-xs text-muted-foreground">Tap "Chat" on a listing to message the seller.</p>
          </div>
        ) : (
          <ul className="space-y-2">
            {data.map((c) => (
              <li key={c.id}>
                <Link to="/chat/$id" params={{ id: c.id }}
                  className="flex items-center gap-3 rounded-2xl bg-card p-3 shadow-card">
                  <div className="h-12 w-12 shrink-0 overflow-hidden rounded-full bg-gradient-primary">
                    {c.other?.avatar_url
                      ? <img src={c.other.avatar_url} alt="" className="h-full w-full object-cover" />
                      : <div className="grid h-full w-full place-items-center text-sm font-bold text-primary-foreground">{(c.other?.full_name ?? "?").charAt(0).toUpperCase()}</div>
                    }
                  </div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center justify-between">
                      <p className="truncate text-sm font-semibold">{c.other?.full_name ?? "Student"}</p>
                      <span className="shrink-0 pl-2 text-[10px] text-muted-foreground">
                        {formatDistanceToNow(new Date(c.last_message_at), { addSuffix: false })}
                      </span>
                    </div>
                    <p className="truncate text-xs text-muted-foreground">
                      {c.product?.title ? `${c.product.title} · ` : ""}{c.last_message ?? "Say hi"}
                    </p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        )}
      </div>
    </AppShell>
  );
}
