import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { ArrowLeft, BadgeCheck, MessageCircle, Phone, MapPin } from "lucide-react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth";

export const Route = createFileRoute("/product/$id")({
  head: () => ({ meta: [{ title: "Listing — Campus" }] }),
  component: ProductPage,
});

const naira = new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 });

function ProductPage() {
  const { id } = Route.useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  const { data: product, isLoading } = useQuery({
    queryKey: ["product", id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("products")
        .select("*, seller:profiles!seller_id(id,full_name,avatar_url,school,verified,trust_score,phone)")
        .eq("id", id)
        .single();
      if (error) throw error;
      return { ...data, seller: Array.isArray(data.seller) ? data.seller[0] : data.seller };
    },
  });

  const startChat = async () => {
    if (!user) return navigate({ to: "/login" });
    if (!product || product.seller_id === user.id) return;
    const { data: existing } = await supabase.from("conversations").select("id")
      .eq("product_id", product.id).eq("buyer_id", user.id).eq("seller_id", product.seller_id).maybeSingle();
    if (existing) return navigate({ to: "/chat/$id", params: { id: existing.id } });
    const { data, error } = await supabase.from("conversations")
      .insert({ product_id: product.id, buyer_id: user.id, seller_id: product.seller_id, last_message: null })
      .select("id").single();
    if (error) return toast.error(error.message);
    navigate({ to: "/chat/$id", params: { id: data.id } });
  };

  if (isLoading) return <div className="grid min-h-screen place-items-center bg-gradient-page text-sm text-muted-foreground">Loading...</div>;
  if (!product) return <div className="grid min-h-screen place-items-center bg-gradient-page text-sm">Not found</div>;

  const isOwner = user?.id === product.seller_id;

  return (
    <div className="mx-auto min-h-screen w-full max-w-md bg-gradient-page pb-32">
      <div className="relative">
        <div className="aspect-square w-full overflow-hidden bg-surface">
          {product.images?.[0]
            ? <img src={product.images[0]} alt={product.title} className="h-full w-full object-cover" />
            : <div className="grid h-full w-full place-items-center text-sm text-muted-foreground">No image</div>}
        </div>
        <Link to="/" className="absolute left-4 top-[max(1rem,env(safe-area-inset-top))] grid h-10 w-10 place-items-center rounded-full bg-background/70 backdrop-blur">
          <ArrowLeft className="h-4 w-4" />
        </Link>
      </div>

      {product.images && product.images.length > 1 && (
        <div className="no-scrollbar flex gap-2 overflow-x-auto px-4 pt-3">
          {product.images.slice(1).map((url: string, i: number) => (
            <img key={i} src={url} alt="" className="h-20 w-20 shrink-0 rounded-xl object-cover" />
          ))}
        </div>
      )}

      <div className="px-4 pt-5">
        <span className="rounded-full bg-surface px-3 py-1 text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          {product.category}
        </span>
        <h1 className="mt-3 font-display text-2xl font-bold leading-tight">{product.title}</h1>
        <p className="mt-1 text-3xl font-bold text-gradient">{naira.format(product.price)}</p>
        {product.school && (
          <p className="mt-2 flex items-center gap-1 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4" />{product.school}
          </p>
        )}
        {product.description && (
          <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed text-foreground/90">{product.description}</p>
        )}
      </div>

      <div className="mx-4 mt-6 rounded-2xl bg-card p-4 shadow-card">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 overflow-hidden rounded-full bg-gradient-primary">
            {product.seller?.avatar_url
              ? <img src={product.seller.avatar_url} alt="" className="h-full w-full object-cover" />
              : <div className="grid h-full w-full place-items-center text-sm font-bold text-primary-foreground">{(product.seller?.full_name ?? "?").charAt(0).toUpperCase()}</div>}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1">
              <p className="truncate text-sm font-semibold">{product.seller?.full_name ?? "Student"}</p>
              {product.seller?.verified && <BadgeCheck className="h-4 w-4 text-primary-glow" />}
            </div>
            <p className="text-xs text-muted-foreground">Trust score · {product.seller?.trust_score ?? 100}</p>
          </div>
        </div>
      </div>

      {!isOwner && (
        <div className="fixed inset-x-0 bottom-0 z-40 mx-auto w-full max-w-md border-t border-border/40 bg-background/85 px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] backdrop-blur-xl">
          <div className="flex gap-2">
            {product.seller?.phone && (
              <a href={`tel:${product.seller.phone}`} className="grid h-12 w-12 place-items-center rounded-full bg-surface">
                <Phone className="h-5 w-5" />
              </a>
            )}
            <button onClick={startChat} className="flex flex-1 items-center justify-center gap-2 rounded-full bg-gradient-primary py-3 text-sm font-semibold text-primary-foreground shadow-glow">
              <MessageCircle className="h-4 w-4" /> Message seller
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
