import { Link } from "@tanstack/react-router";
import { MapPin } from "lucide-react";

export type ProductCardData = {
  id: string;
  title: string;
  price: number;
  images: string[];
  school: string | null;
  category: string;
};

const naira = new Intl.NumberFormat("en-NG", { style: "currency", currency: "NGN", maximumFractionDigits: 0 });

export function ProductCard({ p }: { p: ProductCardData }) {
  const img = p.images[0];
  return (
    <Link
      to="/product/$id"
      params={{ id: p.id }}
      className="group block overflow-hidden rounded-2xl bg-card shadow-card transition-transform active:scale-[0.98]"
    >
      <div className="relative aspect-square overflow-hidden bg-muted">
        {img ? (
          <img src={img} alt={p.title} className="h-full w-full object-cover transition-transform group-hover:scale-105" loading="lazy" />
        ) : (
          <div className="flex h-full w-full items-center justify-center text-xs text-muted-foreground">No image</div>
        )}
        <span className="absolute left-2 top-2 rounded-full bg-background/70 px-2 py-0.5 text-[10px] uppercase tracking-wide backdrop-blur">
          {p.category}
        </span>
      </div>
      <div className="space-y-1 p-3">
        <h3 className="line-clamp-1 text-sm font-semibold">{p.title}</h3>
        <p className="text-base font-bold text-gradient">{naira.format(p.price)}</p>
        {p.school && (
          <p className="flex items-center gap-1 text-[11px] text-muted-foreground">
            <MapPin className="h-3 w-3" />
            {p.school}
          </p>
        )}
      </div>
    </Link>
  );
}
