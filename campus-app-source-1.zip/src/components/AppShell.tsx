import type { ReactNode } from "react";
import { BottomNav } from "./BottomNav";

export function AppShell({ children, hideNav }: { children: ReactNode; hideNav?: boolean }) {
  return (
    <div className="relative mx-auto flex min-h-screen w-full max-w-md flex-col bg-gradient-page">
      <main className="flex-1 pb-24">{children}</main>
      {!hideNav && <BottomNav />}
    </div>
  );
}
