import { Link, useLocation } from "@tanstack/react-router";
import { Home, Search, PlusCircle, MessageCircle, User } from "lucide-react";

const items: { to: "/" | "/search" | "/sell" | "/chat" | "/profile"; icon: typeof Home; label: string; primary?: boolean }[] = [
  { to: "/", icon: Home, label: "Home" },
  { to: "/search", icon: Search, label: "Search" },
  { to: "/sell", icon: PlusCircle, label: "Sell", primary: true },
  { to: "/chat", icon: MessageCircle, label: "Chat" },
  { to: "/profile", icon: User, label: "Me" },
];


export function BottomNav() {
  const { pathname } = useLocation();
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 border-t border-border bg-background/85 backdrop-blur-xl">
      <ul className="mx-auto flex max-w-md items-center justify-around px-2 pt-2 pb-[max(0.5rem,env(safe-area-inset-bottom))]">
        {items.map(({ to, icon: Icon, label, primary }) => {
          const active = to === "/" ? pathname === "/" : pathname.startsWith(to);
          if (primary) {
            return (
              <li key={to}>
                <Link
                  to={to}
                  className="-mt-6 flex h-14 w-14 items-center justify-center rounded-full bg-gradient-primary text-primary-foreground shadow-glow transition-transform active:scale-95"
                  aria-label={label}
                >
                  <Icon className="h-7 w-7" />
                </Link>
              </li>
            );
          }
          return (
            <li key={to}>
              <Link
                to={to}
                className={`flex h-12 w-14 flex-col items-center justify-center gap-0.5 rounded-lg text-[10px] font-medium transition-colors ${
                  active ? "text-primary-glow" : "text-muted-foreground"
                }`}
              >
                <Icon className="h-5 w-5" />
                {label}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
