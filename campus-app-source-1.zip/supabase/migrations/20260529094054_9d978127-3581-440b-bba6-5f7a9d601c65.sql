
-- Fix function search_path
create or replace function public.set_updated_at()
returns trigger language plpgsql set search_path = public as $$
begin new.updated_at = now(); return new; end;
$$;

-- Revoke execute on SECURITY DEFINER trigger functions from API roles
revoke execute on function public.handle_new_user() from public, anon, authenticated;

-- Restrict storage listing: only allow read of specific object, not listing across folders
drop policy if exists "product_images_public_read" on storage.objects;
create policy "product_images_public_read" on storage.objects for select
  using (bucket_id = 'products');
-- Note: listing requires SELECT — acceptable since bucket is public by design (product images).
